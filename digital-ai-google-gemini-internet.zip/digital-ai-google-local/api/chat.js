export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Envie a pergunta por POST." });
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return res.status(503).json({ error: "Falta configurar GEMINI_API_KEY nas variáveis de ambiente do servidor Vercel." });
  }

  const body = req.body && typeof req.body === "object" ? req.body : {};
  const question = typeof body.question === "string" ? body.question.trim() : "";
  if (!question) return res.status(400).json({ error: "Digite uma pergunta." });
  if (question.length > 12000) return res.status(413).json({ error: "A pergunta é muito longa. Envie até 12 mil caracteres." });

  const contents = [];
  for (const m of (Array.isArray(body.history) ? body.history.slice(-8) : [])) {
    if (!m || typeof m.content !== "string") continue;
    if (m.role === "user") contents.push({ role: "user", parts: [{ text: m.content.slice(0, 12000) }] });
    else if (m.role === "assistant" || m.role === "model") contents.push({ role: "model", parts: [{ text: m.content.slice(0, 12000) }] });
  }
  contents.push({ role: "user", parts: [{ text: "Pesquise na internet antes de responder se a pergunta depender de fatos ou informações atuais. Para perguntas escolares, priorize o Brasil Escola (site:brasilescola.uol.com.br e subdomínios oficiais); se não encontrar, amplie para fontes confiáveis. Para outros assuntos, use a web aberta e fontes confiáveis. Cite URLs reais retornadas pela busca e nunca invente fontes.\n\nPergunta: " + question }] });

  const systemInstruction = "Você é Digital AI, uma parceira de conversa gente boa. Fale em português brasileiro natural, informal e acolhedor. CONEXÃO COM A INTERNET: use a ferramenta Google Search sempre que a pergunta depender de fatos, informações atuais, acontecimentos recentes, pessoas, lugares, ciência, tecnologia, dúvidas escolares ou quando o usuário pedir pesquisa. PESQUISA ESCOLAR: para matérias escolares, priorize o Brasil Escola usando site:brasilescola.uol.com.br e subdomínios oficiais; se não encontrar uma página pertinente, amplie para fontes confiáveis e deixe claro que não encontrou no Brasil Escola. PESQUISA GERAL: para outros assuntos factuais, pesquise na web aberta, compare fontes confiáveis e prefira páginas oficiais ou fontes reconhecidas. Responda com suas palavras, indique incertezas e cite links reais retornados pela pesquisa. Nunca invente referências, URLs ou alegações de que visitou um site. Para conversa casual e tarefas criativas que não precisam de fatos atuais, converse naturalmente.";

  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";
  const endpoint = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
      body: JSON.stringify({
        systemInstruction: { parts: [{ text: systemInstruction }] },
        contents,
        tools: [{ google_search: {} }],
        generationConfig: { temperature: 0.8, maxOutputTokens: 4096 }
      })
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) {
      const message = data?.error?.message || "";
      console.error("Gemini API error", response.status, message.slice(0, 300));
      if (response.status === 400) return res.status(502).json({ error: "O Google Gemini recusou a solicitação. Confira o modelo configurado e os parâmetros da API." });
      if (response.status === 401 || response.status === 403) return res.status(502).json({ error: "A chave GEMINI_API_KEY é inválida, não tem permissão ou a API Gemini não está habilitada no projeto Google." });
      if (response.status === 429) return res.status(503).json({ error: "O limite de uso do Google Gemini foi atingido. Confira a cota e o faturamento no Google AI Studio/Google Cloud." });
      return res.status(502).json({ error: `O servidor do Google Gemini respondeu com erro HTTP ${response.status}. Confira as configurações e os logs do deploy.` });
    }

    const candidate = data?.candidates?.[0];
    const answer = (candidate?.content?.parts || []).map(part => part.text || "").join("\n").trim();
    if (!answer) return res.status(502).json({ error: "O Google Gemini não devolveu texto. Tente reformular a pergunta." });

    const sources = new Map();
    for (const chunk of candidate?.groundingMetadata?.groundingChunks || []) {
      const web = chunk?.web;
      if (web?.uri && /^https?:\/\//i.test(web.uri)) {
        try { const host = new URL(web.uri).hostname.toLowerCase(); sources.set(web.uri, { url: web.uri, title: web.title || web.uri, domain: host }); } catch {}
      }
    }
    if (!sources.size) { const isSchool = /\b(escola|escolar|matemática|matematica|história|historia|geografia|biologia|química|quimica|física|fisica|português|portugues|literatura|redação|redacao|vestibular|fotossíntese|fotossintese)\b/i.test(question); const searchUrl = isSchool ? "https://brasilescola.uol.com.br/busca?q=" + encodeURIComponent(question) : "https://www.google.com/search?q=" + encodeURIComponent(question); sources.set(searchUrl, { url: searchUrl, title: isSchool ? "Pesquisar esta pergunta no Brasil Escola" : "Pesquisar esta pergunta na web" }); }
    return res.status(200).json({ answer, sources: [...sources.values()].slice(0, 10), provider: "Google Gemini", research: "Google Search / web" });
  } catch (error) {
    console.error("Gemini network error", error?.message || error);
    return res.status(500).json({ error: "Não foi possível alcançar a API do Google Gemini a partir do servidor. Verifique o deploy e tente novamente." });
  }
}
