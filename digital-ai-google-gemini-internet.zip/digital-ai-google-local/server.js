import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.dirname(fileURLToPath(import.meta.url));
function loadEnv(){
  const p=path.join(root,'.env');
  if(!fs.existsSync(p)) return;
  for(const line of fs.readFileSync(p,'utf8').split(/\r?\n/)){
    const m=line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if(m&&!Object.hasOwn(process.env,m[1])) process.env[m[1]]=m[2].replace(/^(['"])(.*)\1$/,'$2');
  }
}
loadEnv();
const PORT=Number(process.env.PORT||3000);
const mime={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'};
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','Access-Control-Allow-Origin':'null'});res.end(JSON.stringify(data));}
async function bodyJson(req){let raw='';for await(const c of req){raw+=c;if(raw.length>100_000)throw new Error('BODY_TOO_LARGE');}try{return JSON.parse(raw||'{}')}catch{return {};}}
const systemInstruction="Você é Digital AI, uma parceira de conversa gente boa. Fale em português brasileiro natural, informal e acolhedor. CONEXÃO COM A INTERNET: use a ferramenta Google Search sempre que a pergunta depender de fatos, informações atuais, acontecimentos recentes, pessoas, lugares, ciência, tecnologia, dúvidas escolares ou quando o usuário pedir para pesquisar. Não responda a perguntas factuais como se estivesse navegando se não houver fontes de pesquisa retornadas. PESQUISA ESCOLAR: para matérias escolares, priorize o Brasil Escola usando consultas restritas a site:brasilescola.uol.com.br e seus subdomínios oficiais. Se não encontrar uma página pertinente, amplie a pesquisa para fontes confiáveis da web e deixe claro que não encontrou no Brasil Escola. PESQUISA GERAL: para os demais assuntos factuais, pesquise na web aberta, compare fontes confiáveis e prefira páginas oficiais ou fontes reconhecidas. Responda com suas próprias palavras, indique o que é incerto e cite links reais retornados pela pesquisa. Nunca invente referências, URLs ou alegações de que visitou um site. Para cumprimentos, conversa casual, escrita criativa e tarefas que não precisam de fatos atuais, converse naturalmente sem pesquisa desnecessária.";
async function chat(req,res){
 if(req.method!=='POST'){res.setHeader('Allow','POST');return json(res,405,{error:'Envie a pergunta usando POST.'});}
 if(!process.env.GEMINI_API_KEY||process.env.GEMINI_API_KEY==='COLE_SUA_CHAVE_AQUI')return json(res,503,{error:'Falta configurar GEMINI_API_KEY no arquivo .env. Crie sua chave em https://aistudio.google.com/apikey e reinicie o servidor.'});
 let body;try{body=await bodyJson(req)}catch(e){return json(res,413,{error:'A mensagem é muito grande.'});}
 const question=typeof body.question==='string'?body.question.trim():'';
 if(!question)return json(res,400,{error:'Digite uma pergunta.'});
 if(question.length>12000)return json(res,413,{error:'A pergunta é muito longa. Envie até 12 mil caracteres.'});
 const contents=[];
 for(const m of (Array.isArray(body.history)?body.history.slice(-8):[])){
  if(!m||typeof m.content!=='string')continue;
  if(m.role==='user')contents.push({role:'user',parts:[{text:m.content.slice(0,12000)}]});
  else if(m.role==='assistant'||m.role==='model')contents.push({role:'model',parts:[{text:m.content.slice(0,12000)}]});
 }
 contents.push({role:'user',parts:[{text:'Pesquise na internet antes de responder se a pergunta depender de fatos ou informações atuais. Para perguntas escolares, priorize o Brasil Escola (site:brasilescola.uol.com.br e subdomínios oficiais); se não encontrar, amplie para fontes confiáveis. Para outros assuntos, use a web aberta e fontes confiáveis. Cite URLs reais retornadas pela busca e nunca invente fontes.\n\nPergunta: '+question}]});
 const model=process.env.GEMINI_MODEL||'gemini-2.5-flash';
 const endpoint=`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`;
 try{
  const upstream=await fetch(endpoint,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':process.env.GEMINI_API_KEY},body:JSON.stringify({systemInstruction:{parts:[{text:systemInstruction}]},contents,tools:[{google_search:{}}],generationConfig:{temperature:0.8,maxOutputTokens:4096}})});
  const data=await upstream.json().catch(()=>({}));
  if(!upstream.ok){const detail=data?.error?.message||'';console.error('Gemini API error',upstream.status,detail.slice(0,250));if(upstream.status===400)return json(res,502,{error:'O Gemini recusou a solicitação. Confira o modelo ou as configurações da API.'});if(upstream.status===401||upstream.status===403)return json(res,502,{error:'A chave Gemini é inválida ou a API não está habilitada para essa chave.'});if(upstream.status===429)return json(res,503,{error:'A cota/limite do Google Gemini foi atingido. Confira o uso da API no Google AI Studio.'});return json(res,502,{error:`O Google Gemini respondeu com erro HTTP ${upstream.status}. Confira a chave, modelo e disponibilidade.`});}
  const candidate=data?.candidates?.[0];const answer=(candidate?.content?.parts||[]).map(p=>p.text||'').join('\n').trim();
  if(!answer)return json(res,502,{error:'O Google Gemini não devolveu texto. Tente novamente.'});
  const sources=new Map();for(const chunk of candidate?.groundingMetadata?.groundingChunks||[]){const w=chunk?.web;if(w?.uri&&/^https?:\/\//i.test(w.uri)){try{const host=new URL(w.uri).hostname.toLowerCase();sources.set(w.uri,{url:w.uri,title:w.title||w.uri,domain:host});}catch{}}}
  const isSchool=/\b(escola|escolar|matemática|matematica|história|historia|geografia|biologia|química|quimica|física|fisica|português|portugues|literatura|redação|redacao|vestibular|fotossíntese|fotossintese)\b/i.test(question);
  const searchUrl=isSchool?'https://brasilescola.uol.com.br/busca?q='+encodeURIComponent(question):'https://www.google.com/search?q='+encodeURIComponent(question);
  if(!sources.size)sources.set(searchUrl,{url:searchUrl,title:isSchool?'Pesquisar esta pergunta no Brasil Escola':'Pesquisar esta pergunta na web'});
  return json(res,200,{answer,sources:[...sources.values()].slice(0,10),provider:'Google Gemini',research:'Brasil Escola'});
 }catch(e){console.error('Gemini fetch failed',e?.message||e);return json(res,500,{error:'Não foi possível conectar ao Google Gemini. Confira sua conexão com a internet e tente novamente.'});}
}
const server=http.createServer(async(req,res)=>{
 const url=new URL(req.url,'http://localhost');
 if(url.pathname==='/api/health')return json(res,200,{ok:true,provider:'Google Gemini',configured:Boolean(process.env.GEMINI_API_KEY&&process.env.GEMINI_API_KEY!=='COLE_SUA_CHAVE_AQUI'),model:process.env.GEMINI_MODEL||'gemini-2.5-flash',runtime:'local-node'});
 if(url.pathname==='/api/chat')return chat(req,res);
 if(req.method!=='GET'&&req.method!=='HEAD'){res.writeHead(405,{'Allow':'GET, HEAD'});return res.end('Method not allowed');}
 let pathname=decodeURIComponent(url.pathname);if(pathname==='/')pathname='/index.html';const target=path.resolve(root,'.'+pathname);
 if(!target.startsWith(root+path.sep)){res.writeHead(403);return res.end('Forbidden');}
 fs.readFile(target,(err,buf)=>{if(err){res.writeHead(404,{'Content-Type':'text/plain; charset=utf-8'});return res.end('Arquivo não encontrado. Abra http://localhost:'+PORT);}
  res.writeHead(200,{'Content-Type':mime[path.extname(target)]||'application/octet-stream','Cache-Control':'no-store'});if(req.method==='HEAD')return res.end();res.end(buf);
 });
});
server.listen(PORT,'127.0.0.1',()=>{console.log('\nDigital AI está rodando em http://localhost:'+PORT);console.log('Verificação da API: http://localhost:'+PORT+'/api/health');console.log('Chave Gemini: '+(process.env.GEMINI_API_KEY&&process.env.GEMINI_API_KEY!=='COLE_SUA_CHAVE_AQUI'?'configurada':'NÃO configurada — edite o arquivo .env'));console.log('Para encerrar, pressione Ctrl+C.\n');});
