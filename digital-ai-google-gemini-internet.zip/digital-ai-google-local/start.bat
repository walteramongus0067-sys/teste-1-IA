@echo off
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js nao foi encontrado. Instale a versao LTS em https://nodejs.org/ e abra este arquivo novamente.
  pause
  exit /b 1
)
if not exist ".env" (
  copy ".env.example" ".env" >nul
  echo.
  echo Arquivo .env criado.
  echo 1. Abra o arquivo .env no Bloco de Notas.
  echo 2. Troque COLE_SUA_CHAVE_AQUI pela sua chave Gemini.
  echo 3. Salve e execute start.bat novamente.
  echo Obtenha uma chave em https://aistudio.google.com/apikey
  pause
  exit /b 0
)
echo Iniciando Digital AI. Mantenha esta janela aberta.
node server.js
pause
