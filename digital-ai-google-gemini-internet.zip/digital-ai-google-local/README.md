# Digital AI — versão local conectada ao Google Gemini

**Não abra `index.html` com duplo clique.** O navegador precisa acessar a página por meio do servidor local para que `/api/chat` funcione.

## Windows — instalação

1. Instale Node.js LTS (versão 20 ou mais recente): https://nodejs.org/
2. Crie uma chave Gemini: https://aistudio.google.com/apikey
3. Dê duplo clique em `start.bat`. Na primeira execução, ele criará o arquivo `.env` e mostrará o que fazer.
4. Abra o arquivo `.env` no Bloco de Notas e substitua `COLE_SUA_CHAVE_AQUI` pela sua chave, sem apagar `GEMINI_API_KEY=`. Salve o arquivo.
5. Dê duplo clique em `start.bat` novamente e mantenha a janela preta aberta.
6. Abra `http://localhost:3000` no navegador. **Não use o caminho `file:///.../index.html`.**
7. Para verificar a configuração, abra `http://localhost:3000/api/health`. O JSON deve mostrar `"configured":true`.

## Diagnóstico

- `configured:false`: a chave não está preenchida corretamente no `.env`, ou o servidor não foi reiniciado.
- Erro 401/403: chave incorreta, sem permissão, ou API não habilitada.
- Erro 429: limite/cota do Google Gemini atingido.
- Página não abre: confira se o Node.js está instalado e se a janela do servidor continua aberta.

A chave fica no `.env` local e não deve ser publicada no GitHub nem colocada no HTML. A API Gemini pode ter limites de uso e requisitos de cobrança. Para parar o servidor, pressione Ctrl+C na janela preta.


## Pesquisa na internet mundial

A Digital AI usa a ferramenta Google Search integrada ao Gemini para pesquisar informações na web. Em assuntos escolares, prioriza o Brasil Escola; quando não encontra material pertinente, deve ampliar a pesquisa para fontes confiáveis. Em outros assuntos factuais e atuais, pesquisa na web aberta e exibe links reais retornados pelo Google Search. Se a pesquisa não retornar links, a interface oferece um link de busca como alternativa. A qualidade e a disponibilidade dependem da conexão, da chave Gemini, do modelo e dos limites da API. Isso não significa acesso irrestrito a todos os sites ou a conteúdos protegidos por login.
