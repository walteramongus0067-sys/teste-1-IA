# Digital AI

Assistente web em português para pesquisa com fontes e ajuda em programação. O projeto prioriza fontes primárias e transparência sobre incertezas — nenhuma IA pode garantir que todas as respostas sejam 100% verdadeiras.

## O que inclui
- Interface responsiva em português.
- Pesquisa na web pela ferramenta `web_search` da OpenAI Responses API.
- Respostas com links das fontes disponíveis.
- Assistência para programação.
- Tratamento de erros sem expor a chave da API no navegador.
- Orientação para distinguir fatos, inferências e incertezas.

## Como publicar no Vercel
1. Entre em [Vercel](https://vercel.com/) e importe este repositório do GitHub.
2. Nas configurações do projeto, abra **Settings → Environment Variables**.
3. Adicione `OPENAI_API_KEY` com sua chave da API OpenAI.
4. Opcionalmente, defina `OPENAI_MODEL` com um modelo disponível na sua conta. O padrão é `gpt-4.1-mini`.
5. Faça o deploy ou redeploy.

O Vercel reconhece `index.html` como página estática e `api/chat.js` como função serverless Node.js.

## Segurança e custos
- **Nunca** coloque a chave da API em `index.html`, no código do navegador ou em um commit público.
- Use uma chave própria, mantenha-a como variável de ambiente no servidor e monitore uso e limites.
- O uso da API pode gerar cobranças conforme os preços e limites da sua conta.
- Antes de disponibilizar publicamente, considere adicionar autenticação, limitação de solicitações e proteção contra abuso.

## Desenvolvimento local
É necessário Node.js e Vercel CLI. Configure `OPENAI_API_KEY` em um arquivo local de ambiente que não seja enviado ao Git, depois execute:

```bash
npx vercel dev
```

## Limites de confiabilidade
As fontes ajudam a conferir informações, mas não garantem que cada resposta esteja correta. Verifique afirmações importantes nas páginas originais, confira datas e compare fontes independentes quando necessário.
